"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

import {
  LayoutDashboard,
  FileText,
  Target,
  Brain,
  Download,
  Settings,
  LogOut,
} from "lucide-react";

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  const menu = [
    {
      icon: LayoutDashboard,
      name: "Dashboard",
      href: "/dashboard",
    },
    {
      icon: FileText,
      name: "Resume Analyzer",
      href: "/dashboard",
    },
    {
      icon: Target,
      name: "JD Matcher",
      href: "/dashboard",
    },
    {
      icon: Brain,
      name: "Interview Prep",
      href: "/dashboard",
    },
    {
      icon: Download,
      name: "Reports",
      href: "/reports",
    },
  ];

  return (
    <aside className="flex h-screen w-72 flex-col justify-between border-r border-slate-800 bg-slate-900 p-6">

      {/* Logo */}

      <div>

        <div className="mb-12">

          <h1 className="text-3xl font-bold tracking-tight text-white">
            DevTrack
            <span className="text-blue-600"> AI</span>
          </h1>

          <p className="mt-2 text-sm text-slate-400">
            AI Resume Analyzer
          </p>

        </div>

        {/* Navigation */}

        <nav className="space-y-2">

          {menu.map((item) => {
            const Icon = item.icon;

            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex w-full items-center gap-4 rounded-xl px-4 py-3 transition-all duration-300 ${
                  pathname === item.href
                    ? "bg-blue-600 text-white shadow-lg"
                    : "text-slate-400 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <Icon size={20} />

                <span className="font-medium">
                  {item.name}
                </span>

              </Link>
            );
          })}

        </nav>

      </div>

      {/* Bottom */}

      <div className="space-y-2 border-t border-slate-800 pt-6">

        <Link
          href="/settings"
          className={`flex w-full items-center gap-4 rounded-xl px-4 py-3 transition-all duration-300 ${
            pathname === "/settings"
              ? "bg-blue-600 text-white shadow-lg"
              : "text-slate-400 hover:bg-slate-800 hover:text-white"
          }`}
        >
          <Settings size={20} />

          <span>Settings</span>

        </Link>

        <button
          onClick={() => router.push("/login")}
          className="flex w-full items-center gap-4 rounded-xl px-4 py-3 text-rose-400 transition-all duration-300 hover:bg-rose-500/10"
        >
          <LogOut size={20} />

          <span>Logout</span>

        </button>

      </div>

    </aside>
  );
}