"use client";

import Sidebar from "../../components/layout/Sidebar";
import Header from "../../components/layout/Header";
import Dashboard from "./Dashboard";
export default function DashboardPage() {
  return (
    <main className="flex min-h-screen bg-slate-950 text-white">
      <Sidebar />

      <section className="flex-1 p-10">
        <Header />
        <Dashboard />
      </section>
    </main>
  );
}