"use client";

import { useState } from "react";
import ResumeUpload from "@/components/dashboard/ResumeUpload";
export default function Dashboard() {
  const [analysis, setAnalysis] = useState(null);
  const [resumeText, setResumeText] = useState("");
  const [jdResult, setJdResult] = useState(null);

  return (
    <section className="mx-auto mt-24 max-w-7xl px-8">

      <ResumeUpload
        analysis={analysis}
        setAnalysis={setAnalysis}
        resumeText={resumeText}
        setResumeText={setResumeText}
        jdResult={jdResult}
        setJdResult={setJdResult}
      />

    </section>
  );
}